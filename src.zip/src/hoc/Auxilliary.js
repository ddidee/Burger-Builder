
function Auxilliary(props) {
  return props.children
}

export default Auxilliary
